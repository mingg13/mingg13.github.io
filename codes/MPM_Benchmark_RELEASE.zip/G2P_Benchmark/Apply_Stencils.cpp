// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include <array>
#include <immintrin.h>

void Apply_Stencils(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float grid_datas[6][8][8][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p)
{
    // si sj sk : smallest i,j,k : [0,6]
    // output 0-2 velocity0 3-5 velocity 6-15 outer_product

    __m256i vCellNodes      =_mm256_set_epi32(73, 72, 65, 64, 9, 8, 1, 0);
    float __attribute__ ((aligned(64))) sum[8];
    using Matrix3x3_Type = float (&)[3][3];

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    int start=m*512+(si+i)*64+(sj+j)*8+(sk+k);
                    __m256i vNodeIndices=_mm256_set1_epi32(start);
                    vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                    __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); // didn't mention
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v_p[m]=0.f;
        for(int v=0;v<8;++v)
        v_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    int start=(m+3)*512+(si+i)*64+(sj+j)*8+(sk+k);
                    __m256i vNodeIndices=_mm256_set1_epi32(start);
                    vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                    __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); // didn't mention
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v0_p[m]=0.f;
        for(int v=0;v<8;++v)
        v0_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
            __m256 vSum0=_mm256_setzero_ps();
            __m256 vSum1=_mm256_setzero_ps();
            __m256 vSum2=_mm256_setzero_ps();
            for(int i=0;i<2;++i)
                for(int j=0;j<2;++j)
                    for(int k=0;k<2;++k)
                    {
                        int start=m*512+(si+i)*64+(sj+j)*8+(sk+k);
                        __m256i vNodeIndices=_mm256_set1_epi32(start);
                        vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                        __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); 

                        __m256 vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][0][0])); 
                        __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum0=_mm256_add_ps(vSumTMP,vSum0);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][1][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum1=_mm256_add_ps(vSumTMP,vSum1);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][2][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum2=_mm256_add_ps(vSumTMP,vSum2);
                    }

            Matrix3x3_Type mG_p=reinterpret_cast<Matrix3x3_Type>(G_p[0]);

            _mm256_store_ps(sum,vSum0);
            for(int v=0;v<8;++v) mG_p[0][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum1);
            for(int v=0;v<8;++v) mG_p[1][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum2);
            for(int v=0;v<8;++v) mG_p[2][m]+=sum[v];

    }
}

void Apply_Stencils_Alt(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float cell_data[6][5][5][5][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p)
{
    // si sj sk : smallest i,j,k : [0,6]
    // output 0-2 velocity0 3-5 velocity 6-15 outer_product

    float __attribute__ ((aligned(64))) sum[8];
    using Matrix3x3_Type = float (&)[3][3];

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    __m256 vNodeValues=_mm256_load_ps(&cell_data[m][i+si][j+sj][k+sk][0]);
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v_p[m]=0.f;
        for(int v=0;v<8;++v)
        v_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    __m256 vNodeValues=_mm256_load_ps(&cell_data[m+3][i+si][j+sj][k+sk][0]);
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v0_p[m]=0.f;
        for(int v=0;v<8;++v)
        v0_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
            __m256 vSum0=_mm256_setzero_ps();
            __m256 vSum1=_mm256_setzero_ps();
            __m256 vSum2=_mm256_setzero_ps();
            for(int i=0;i<2;++i)
                for(int j=0;j<2;++j)
                    for(int k=0;k<2;++k)
                    {
                        __m256 vNodeValues=_mm256_load_ps(&cell_data[m][i+si][j+sj][k+sk][0]);
                        __m256 vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][0][0])); 
                        __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum0=_mm256_add_ps(vSumTMP,vSum0);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][1][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum1=_mm256_add_ps(vSumTMP,vSum1);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][2][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum2=_mm256_add_ps(vSumTMP,vSum2);
                    }

            Matrix3x3_Type mG_p=reinterpret_cast<Matrix3x3_Type>(G_p[0]);

            _mm256_store_ps(sum,vSum0);
            for(int v=0;v<8;++v) mG_p[0][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum1);
            for(int v=0;v<8;++v) mG_p[1][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum2);
            for(int v=0;v<8;++v) mG_p[2][m]+=sum[v];

    }
}

