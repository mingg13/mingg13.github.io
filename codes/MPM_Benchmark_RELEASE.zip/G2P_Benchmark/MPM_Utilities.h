// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#ifndef __MPM_Utilities_h__
#define __MPM_Utilities_h__

template<class T,int d> class MPM_Data;

template<class T,int d>
void Update_Particle_Embedding(MPM_Data<T,d>& data);

template<class T,int d>
void Update_Block_Particle_Lists(MPM_Data<T,d>& data);

#endif
