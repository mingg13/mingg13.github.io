// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include "MPM_Data.h"
#include <PhysBAM_Tools/Grids_Uniform/GRID.h>
#include <PhysBAM_Tools/Math_Tools/RANGE.h>
#include <PhysBAM_Tools/Vectors/VECTOR_3D.h>
#include <Common_Tools/Math_Tools/RANGE_ITERATOR.h>
using namespace PhysBAM;
#include "Particle_Box_Initializer.h"
//#####################################################################
// Function Initialize_Particles_In_Box
//#####################################################################
template<>
void Initialize_Particles_In_Box(const RANGE<VECTOR<int,3> >& particle_box,const GRID<VECTOR<float,3> >& grid,MPM_Data<float,3>& data)
{
    constexpr int d = 3;

    using T           = float;
    using T_INDEX     = VECTOR<int,d>;
    using T_RANGE     = RANGE<T_INDEX>;
    using TV          = VECTOR<T,d>;
    using Vector_Type = std::array<T,d>;

    LOG::SCOPE scope("Initialize_Particles_In_Box()");

    for(RANGE_ITERATOR<d> cell_iterator(particle_box);cell_iterator.Valid();cell_iterator.Next())
        for(RANGE_ITERATOR<d> point_iterator(T_RANGE::Unit_Box());point_iterator.Valid();point_iterator.Next()){
            TV x=grid.Center(cell_iterator.Index())+TV(point_iterator.Index())*.5f*grid.dX.x-.25f*grid.dX.x;
            data.x_p.push_back(Vector_Type{{x.x,x.y,x.z}});}

    LOG::cout<<"Total particles : "<<data.x_p.size()<<std::endl;

    data.m_p.resize(data.x_p.size());
    data.V0_p.resize(data.x_p.size());
    data.v_p.resize(data.x_p.size());
    data.v_p0.resize(data.x_p.size());
    data.F_p.resize(data.x_p.size());
}
