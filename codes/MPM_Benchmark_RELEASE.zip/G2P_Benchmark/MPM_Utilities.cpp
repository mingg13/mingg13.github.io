// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include "parallel_stable_sort/openmp/parallel_stable_sort.h"
#include "MPM_Data.h"
#include <PhysBAM_Tools/Log/LOG.h>
using namespace PhysBAM;
#include "MPM_Utilities.h"
//#####################################################################
// Function Update_Particle_Embedding
//#####################################################################
template<>
void Update_Particle_Embedding(MPM_Data<float,3>& data)
{
    constexpr int d = 3;
    using T               = float;
    using Vector_Type     = std::array<T,d>;
    using Index_Type      = std_array<int,d>;
    using Coord_Type      = std::array<int,d>;
    using Data_Array_Mask = MPM_Data<T,d>::Allocator_Type::Array<T>::mask;

    LOG::SCOPE scope("Update_Particle_Embedding()");

    const int nparticles=data.x_p.size();
    const T one_over_dx=1.f/data.dx;

    data.base_offset_p.resize(nparticles);
    data.local_offset_p.resize(nparticles);
    data.trilinear_coordinates_p.resize(nparticles);

#pragma omp parallel for
    for(int p=0;p<nparticles;p++){

        Vector_Type x_scaled;
        Index_Type base_index;
        Coord_Type local_index;
        Vector_Type trilinear_coordinates;
        
        for(int v=0;v<d;v++){
            x_scaled[v] = data.x_p[p][v]*one_over_dx;
            base_index(v) = static_cast<int>(x_scaled[v]+.5f)-1;
            local_index[v] = base_index(v) & 0x3;
            trilinear_coordinates[v] = x_scaled[v]-static_cast<T>(base_index(v)+1);
        }

        data.trilinear_coordinates_p[p]=trilinear_coordinates;
        data.base_offset_p[p]=Data_Array_Mask::Linear_Offset(base_index);
        data.local_offset_p[p]=local_index;

    }
}
//#####################################################################
// Function Update_Block_Particle_Lists
//#####################################################################
template<>
void Update_Block_Particle_Lists(MPM_Data<float,3>& data)
{
    LOG::SCOPE scope("Update_Block_Particle_Lists");

    const int nparticles=data.x_p.size();

    data.sorted_particle_indices.resize(nparticles);

    for(int p=0;p<nparticles;p++)
        data.sorted_particle_indices[p]=p;

    pss::parallel_stable_sort(data.sorted_particle_indices.begin(),data.sorted_particle_indices.end(),
        [&data](int i,int j) { return data.base_offset_p[i]<data.base_offset_p[j]; }
    );

    data.G2P_blocks.clear();
    data.G2P_offsets.clear();

    unsigned long offset=0xfffffffffffffffful;
    for(int p=0;p<nparticles;p++){
        unsigned long next_offset=data.base_offset_p[data.sorted_particle_indices[p]] & 0xfffffffffffff000ul;
        if(next_offset!=offset){
            offset=next_offset;
            data.G2P_blocks.push_back(offset);
            data.G2P_offsets.push_back(p);}}
    data.G2P_offsets.push_back(nparticles);
}
