// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include <stdlib.h>
#include <immintrin.h>
#include <iostream>
#include <stdint.h>

const float __attribute__ ((aligned(64))) aZero[8] ={ .0f, .0f, .0f, .0f, .0f, .0f, .0f, .0f };
const float __attribute__ ((aligned(64))) aOne[8] = { 1.f, 1.f, 1.f, 1.f, 1.f, 1.f, 1.f, 1.f };
const float __attribute__ ((aligned(64))) aMinusOne[8] = {-1.f,-1.f,-1.f,-1.f,-1.f,-1.f,-1.f,-1.f };
const float __attribute__ ((aligned(64))) aOneEighth[8] = {.125f,.125f,.125f,.125f,.125f,.125f,.125f,.125f };
const float __attribute__ ((aligned(64))) aOneFourth[8] = {.25f,.25f,.25f,.25f,.25f,.25f,.25f,.25f };

const float __attribute__ ((aligned(64))) aWxOffset[8] = { 1.f, 1.f, 1.f, 1.f, 0.f, 0.f, 0.f, 0.f };
const float __attribute__ ((aligned(64))) aWyOffset[8] = { 1.f, 1.f, 0.f, 0.f, 1.f, 1.f, 0.f, 0.f };
const float __attribute__ ((aligned(64))) aWzOffset[8] = { 1.f, 0.f, 1.f, 0.f, 1.f, 0.f, 1.f, 0.f };

//extern uint64_t ticks;

void Build_Stencils(const float w1, const float w2, const float w3, const float radius, float stencils[8][8], float gstencils[8][3][8])
{
    //uint64_t t_start=_rdtsc();

    float __attribute__ ((aligned(64))) aA[8];
    float __attribute__ ((aligned(64))) aB[8];
    float __attribute__ ((aligned(64))) aC[8];
    float __attribute__ ((aligned(64))) aD[8];
    float __attribute__ ((aligned(64))) aE[8];
    float __attribute__ ((aligned(64))) aF[8];
    
    __m256 vMinusOne        = _mm256_load_ps(aMinusOne);
    __m256 vOneEighth       = _mm256_load_ps(aOneEighth);
    __m256 vOneFourth       = _mm256_load_ps(aOneFourth);
    __m256 vRadius          = _mm256_broadcast_ss(&radius);
    __m256 vWxOffset        = _mm256_load_ps(aWxOffset);
    __m256 vWyOffset        = _mm256_load_ps(aWyOffset);
    __m256 vWzOffset        = _mm256_load_ps(aWzOffset);
    __m256 vOne             = _mm256_load_ps(aOne);
    __m256 vZero            = _mm256_load_ps(aZero);

    __m256 vA = _mm256_broadcast_ss(&w1);
    vA=_mm256_sub_ps(vA,vRadius);
    vA=_mm256_add_ps(vA,vWxOffset);
    vA=_mm256_max_ps(vA,vZero);
    vA=_mm256_min_ps(vA,vOne);
    _mm256_store_ps(aA,vA);
    
    __m256 vB = _mm256_broadcast_ss(&w1);
    vB=_mm256_add_ps(vB,vRadius);
    vB=_mm256_add_ps(vB,vWxOffset);
    vB=_mm256_max_ps(vB,vZero);
    vB=_mm256_min_ps(vB,vOne);
    _mm256_store_ps(aB,vB);

    __m256 vC = _mm256_broadcast_ss(&w2);
    vC=_mm256_sub_ps(vC,vRadius);
    vC=_mm256_add_ps(vC,vWyOffset);
    vC=_mm256_max_ps(vC,vZero);
    vC=_mm256_min_ps(vC,vOne);
    _mm256_store_ps(aC,vC);
    
    __m256 vD = _mm256_broadcast_ss(&w2);
    vD=_mm256_add_ps(vD,vRadius);
    vD=_mm256_add_ps(vD,vWyOffset);
    vD=_mm256_max_ps(vD,vZero);
    vD=_mm256_min_ps(vD,vOne);
    _mm256_store_ps(aD,vD);

    __m256 vE = _mm256_broadcast_ss(&w3);
    vE=_mm256_sub_ps(vE,vRadius);
    vE=_mm256_add_ps(vE,vWzOffset);
    vE=_mm256_max_ps(vE,vZero);
    vE=_mm256_min_ps(vE,vOne);
    _mm256_store_ps(aE,vE);
    
    __m256 vF = _mm256_broadcast_ss(&w3);
    vF=_mm256_add_ps(vF,vRadius);
    vF=_mm256_add_ps(vF,vWzOffset);
    vF=_mm256_max_ps(vF,vZero);
    vF=_mm256_min_ps(vF,vOne);
    _mm256_store_ps(aF,vF);

    for(int i=0;i<8;i++)
    {
        __m256 vA=_mm256_broadcast_ss(&aA[i]);
        __m256 vB=_mm256_broadcast_ss(&aB[i]);
        __m256 vC=_mm256_broadcast_ss(&aC[i]);
        __m256 vD=_mm256_broadcast_ss(&aD[i]);
        __m256 vE=_mm256_broadcast_ss(&aE[i]);
        __m256 vF=_mm256_broadcast_ss(&aF[i]);

        __m256 vOneMinusA=_mm256_add_ps(vA,vMinusOne);
        vOneMinusA=_mm256_mul_ps(vOneMinusA,vMinusOne);
        __m256 vOneMinusB=_mm256_add_ps(vB,vMinusOne);
        vOneMinusB=_mm256_mul_ps(vOneMinusB,vMinusOne);
        __m256 vXmin=_mm256_blend_ps(vA,vOneMinusB,0x0f);
        __m256 vXmax=_mm256_blend_ps(vB,vOneMinusA,0x0f);

        __m256 vOneMinusC=_mm256_add_ps(vC,vMinusOne);
        vOneMinusC=_mm256_mul_ps(vOneMinusC,vMinusOne);
        __m256 vOneMinusD=_mm256_add_ps(vD,vMinusOne);
        vOneMinusD=_mm256_mul_ps(vOneMinusD,vMinusOne);
        __m256 vYmin=_mm256_blend_ps(vC,vOneMinusD,0x33);
        __m256 vYmax=_mm256_blend_ps(vD,vOneMinusC,0x33);    

        __m256 vOneMinusE=_mm256_add_ps(vE,vMinusOne);
        vOneMinusE=_mm256_mul_ps(vOneMinusE,vMinusOne);
        __m256 vOneMinusF=_mm256_add_ps(vF,vMinusOne);
        vOneMinusF=_mm256_mul_ps(vOneMinusF,vMinusOne);
        __m256 vZmin=_mm256_blend_ps(vE,vOneMinusF,0x55);
        __m256 vZmax=_mm256_blend_ps(vF,vOneMinusE,0x55);

        __m256 vtmp0=_mm256_mul_ps(vXmax,vXmax);
        __m256 vtmp1=_mm256_mul_ps(vXmin,vXmin);
        vtmp0=_mm256_sub_ps(vtmp0,vtmp1);
        vtmp1=_mm256_sub_ps(vXmax,vXmin); // g
        __m256 vtmp11=_mm256_sub_ps(vXmin,vXmax); 
        vtmp1=_mm256_blend_ps(vtmp1,vtmp11,0x0f); 

        __m256 vtmp2=_mm256_mul_ps(vYmax,vYmax);
        __m256 vtmp3=_mm256_mul_ps(vYmin,vYmin);
        vtmp2=_mm256_sub_ps(vtmp2,vtmp3);
        vtmp3=_mm256_sub_ps(vYmax,vYmin); // g
        __m256 vtmp33=_mm256_sub_ps(vYmin,vYmax); 
        vtmp3=_mm256_blend_ps(vtmp3,vtmp33,0x33); 

        __m256 vtmp4=_mm256_mul_ps(vZmax,vZmax);
        __m256 vtmp5=_mm256_mul_ps(vZmin,vZmin);
        vtmp4=_mm256_sub_ps(vtmp4,vtmp5);
        vtmp5=_mm256_sub_ps(vZmax,vZmin); // g
        __m256 vtmp55=_mm256_sub_ps(vZmin,vZmax); 
        vtmp5=_mm256_blend_ps(vtmp5,vtmp55,0x55); 

        __m256 vStencil=_mm256_mul_ps(vtmp0,vtmp2);
        vStencil=_mm256_mul_ps(vStencil,vtmp4);
        vStencil=_mm256_mul_ps(vStencil,vOneEighth);
        _mm256_storeu_ps(stencils[i],vStencil);

        vStencil=_mm256_mul_ps(vtmp1,vtmp2);
        vStencil=_mm256_mul_ps(vStencil,vtmp4);
        vStencil=_mm256_mul_ps(vStencil,vOneFourth);
        _mm256_storeu_ps(gstencils[i][0],vStencil);

        vStencil=_mm256_mul_ps(vtmp3,vtmp0);
        vStencil=_mm256_mul_ps(vStencil,vtmp4);
        vStencil=_mm256_mul_ps(vStencil,vOneFourth);
        _mm256_storeu_ps(gstencils[i][1],vStencil);

        vStencil=_mm256_mul_ps(vtmp5,vtmp0);
        vStencil=_mm256_mul_ps(vStencil,vtmp2);
        vStencil=_mm256_mul_ps(vStencil,vOneFourth);
        _mm256_storeu_ps(gstencils[i][2],vStencil);

    }

    //uint64_t t_end=_rdtsc();

    //ticks += (t_end-t_start);

    return;
}
