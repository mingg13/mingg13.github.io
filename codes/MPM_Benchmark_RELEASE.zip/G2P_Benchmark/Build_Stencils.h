// Copyright (C) 2017, Anonymous Authors of submission papers_0282

void Build_Stencils(const float w1, const float w2, const float w3, const float radius, float stencils[8][8], float gstencils[8][3][8]);

