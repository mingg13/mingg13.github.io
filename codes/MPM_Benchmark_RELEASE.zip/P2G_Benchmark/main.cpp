// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include "MPM_Data.h"

#include <PhysBAM_Tools/Grids_Uniform/GRID.h>
#include <PhysBAM_Tools/Math_Tools/RANGE.h>
#include <PhysBAM_Tools/Parsing/PARSE_ARGS.h>
#include <PhysBAM_Tools/Vectors/VECTOR_3D.h>

using namespace PhysBAM;

#include "Particle_Box_Initializer.h"
#include "MPM_Utilities.h"
#include "MPM_Particle2Grid.h"

int main(int argc,char* argv[])
{ 
    constexpr int d = 3;

    using T       = float;
    using T_INDEX = VECTOR<int,d>;
    using T_RANGE = RANGE<T_INDEX>;
    using TV      = VECTOR<T,d>;
    using T_GRID  = GRID<TV>;

    LOG::Initialize_Logging();

    PARSE_ARGS parse_args;
    parse_args.Add_Vector_3D_Argument("-size",VECTOR<double,3>(128.f,128.f,128.f),"n n n","Grid size");
    parse_args.Add_Vector_3D_Argument("-min_corner",VECTOR<double,3>(16.f,16.f,16.f),"n n n","Minimum corner of particle box");
    parse_args.Add_Vector_3D_Argument("-max_corner",VECTOR<double,3>(111.f,111.f,111.f),"n n n","Maximum corner (inclusive) of particle box");    
    parse_args.Add_Double_Argument("-dx",1.f/128.f,"f","Grid cell size");
    parse_args.Parse(argc,argv);

    T_INDEX size(parse_args.Get_Vector_3D_Value("-size"));
    T_INDEX min_corner(parse_args.Get_Vector_3D_Value("-min_corner"));
    T_INDEX max_corner(parse_args.Get_Vector_3D_Value("-max_corner"));
    T dx=parse_args.Get_Double_Value("-dx");
    
    T_RANGE particle_box(min_corner,max_corner);
    T_GRID grid(T_INDEX::All_Ones_Vector()*2,RANGE<TV>(TV::All_Ones_Vector()*dx,TV::All_Ones_Vector()*2.f*dx));

    LOG::cout<<"Grid size    = "<<size<<std::endl;
    LOG::cout<<"Particle box = "<<particle_box<<std::endl;
    LOG::cout<<"dx           = "<<dx<<std::endl;

    MPM_Data<T,d> data;
    data.dx=dx;
    data.radius=.5f; // Half-cell; this reflects what the radius is at the finest level of adaptivity
    data.alpha=.125f/(data.radius*data.radius*data.radius);
    data.beta=.125f/(data.radius*data.radius*data.radius*dx);

    data.Initialize_SPGrid(size.x,size.y,size.z);

    Initialize_Particles_In_Box(particle_box,grid,data);

    Update_Particle_Embedding(data);
    Update_Block_Particle_Lists(data);
    
    posix_memalign(&data.block_buffers,64,data.G2P_blocks.size()*7*8*8*8*4);

    while(1)
        P2G_Transfer(data);

    LOG::Finish_Logging();

    return 0;
}

