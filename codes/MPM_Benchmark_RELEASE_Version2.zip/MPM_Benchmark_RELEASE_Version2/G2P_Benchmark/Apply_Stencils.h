// Copyright (C) 2017, Anonymous Authors of submission papers_0282

void Apply_Stencils(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float grid_datas[6][8][8][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p);

void Apply_Stencils_Alt(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float cell_data[6][5][5][5][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p);
