// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#ifndef __MPM_Grid2Particle_h__
#define __MPM_Grid2Particle_h__

template<class T,int d> class MPM_Data;

template<class T,int d>
void G2P_Transfer(MPM_Data<T,d>& data);

#endif
