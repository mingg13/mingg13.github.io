// Copyright (C) 2017, Anonymous Authors of submission papers_0282

//#####################################################################
// Class MPM_Grid_Data
//#####################################################################
#ifndef __MPM_Grid_Data_h__
#define __MPM_Grid_Data_h__

template<class T>
struct MPM_Grid_Data
{
    unsigned flags;
    T ch0;
    T ch1;
    T ch2;
    T ch3;
    T ch4;
    T ch5;
    T ch6;
    T ch7;
    T ch8;
    T ch9;
    T ch10;
    T ch11;
    T ch12;
    T ch13;
    T ch14;
};
#endif
