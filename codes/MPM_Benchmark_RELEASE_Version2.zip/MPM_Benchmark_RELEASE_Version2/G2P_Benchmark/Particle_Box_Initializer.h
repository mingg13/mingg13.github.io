// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#ifndef __Particle_Box_Initializer_h__
#define __Particle_Box_Initializer_h__

template<class T,int d> class MPM_Data;

template<class T,int d>
void Initialize_Particles_In_Box(const RANGE<VECTOR<int,d> >& particle_box,const GRID<VECTOR<T,d> >& grid,MPM_Data<T,d>& data);

#endif
