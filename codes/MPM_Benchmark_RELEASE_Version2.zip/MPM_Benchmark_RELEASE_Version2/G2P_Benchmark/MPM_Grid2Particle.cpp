// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include <immintrin.h>

#include "MPM_Data.h"
#include "Build_Stencils.h"
#include "Apply_Stencils.h"

#include <PhysBAM_Tools/Log/LOG.h>

using namespace PhysBAM;
using namespace SPGrid;

#include "MPM_Grid2Particle.h"

//#####################################################################
// Function G2P_Transfer
//#####################################################################
template<>
void G2P_Transfer(MPM_Data<float,3>& data)
{
    constexpr int d = 3;
    using T               = float;
//     using Vector_Type     = std::array<T,d>;
//     using Index_Type      = std_array<int,d>;
    using Data_Array_Mask = MPM_Data<T,d>::Allocator_Type::Array<T>::mask;

    LOG::SCOPE scope("G2P_Transfer");

    const int nblocks=data.G2P_blocks.size();

    T __attribute__ ((aligned(64))) buffer[3][8][8][8];
    T __attribute__ ((aligned(64))) cell_buffer[3][5][5][5][8];
    T __attribute__ ((aligned(64))) stencils[8][8];
    T __attribute__ ((aligned(64))) gstencils[8][3][8];using Reshaped_Buffer_Type = T (&)[3][2][4][2][4][2][4];
    using Reshaped_Channel_Type = const T (&)[4][4][4];
    using Matrix3x3_Type = T (&)[3][3];

#pragma omp parallel for private(buffer,cell_buffer,stencils,gstencils)
    for(int b=0;b<nblocks;b++){

        unsigned long neighbor_offsets[2][2][2];
        neighbor_offsets[0][0][0]=data.G2P_blocks[b];
        neighbor_offsets[0][0][1]=Data_Array_Mask::Packed_Offset<0,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][0]=Data_Array_Mask::Packed_Offset<0,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][1]=Data_Array_Mask::Packed_Offset<0,4,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][0]=Data_Array_Mask::Packed_Offset<4,0,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][1]=Data_Array_Mask::Packed_Offset<4,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][0]=Data_Array_Mask::Packed_Offset<4,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][1]=Data_Array_Mask::Packed_Offset<4,4,4>(data.G2P_blocks[b]);

        Reshaped_Buffer_Type buffer_reshaped=reinterpret_cast<Reshaped_Buffer_Type>(buffer[0][0][0][0]);

        for(int v=0;v<d;v++){

            auto vg_component_array=data.allocator_ptr->Get_Const_Array(data.vg_ptrs[v]);

            for(int bi=0;bi<2;bi++)
            for(int bj=0;bj<2;bj++)
            for(int bk=0;bk<2;bk++){

                Reshaped_Channel_Type channel_reshaped=
                    reinterpret_cast<Reshaped_Channel_Type>(vg_component_array(neighbor_offsets[bi][bj][bk]));

                for(int i=0;i<4;i++)
                for(int j=0;j<4;j++)
                for(int k=0;k<4;k++)
                    buffer_reshaped[v][bi][i][bj][j][bk][k]=channel_reshaped[i][j][k];

            }
        }

        __m256i vCellNodes = _mm256_set_epi32(73, 72, 65, 64, 9, 8, 1, 0);

        for(int v=0;v<d;v++)
            for(int i=0;i<5;i++)
            for(int j=0;j<5;j++)
            for(int k=0;k<5;k++)
            {
                __m256 vCellData = _mm256_i32gather_ps(&(buffer[v][i][j][k]),vCellNodes,4);
                _mm256_store_ps(&cell_buffer[v][i][j][k][0],vCellData);
            }

        for(int pp=data.G2P_offsets[b];pp<data.G2P_offsets[b+1];pp++){

            int p=data.sorted_particle_indices[pp];
            const auto weights=data.trilinear_coordinates_p[p];
            const auto local_offset=data.local_offset_p[p];

            Build_Stencils(weights[0],weights[1],weights[2],data.radius,stencils,gstencils);

            std::array<T,9> G_p={0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f,0.f};
            Matrix3x3_Type mF_p=reinterpret_cast<Matrix3x3_Type>(data.F_p[p][0]);
            Matrix3x3_Type mG_p=reinterpret_cast<Matrix3x3_Type>(G_p[0]);
            //Apply_Stencils(local_offset[0],local_offset[1],local_offset[2],stencils,gstencils,buffer,data.v_p[p],data.v_p0[p],,G_p);
            Apply_Stencils_Alt(local_offset[0],local_offset[1],local_offset[2],stencils,gstencils,cell_buffer,data.v_p[p],data.v_p0[p],G_p);

            for(int i=0;i<3;i++) data.v_p[p][i] *= data.alpha;
            for(int i=0;i<3;i++) data.v_p0[p][i] *= data.alpha;
            for(int j=0;j<3;j++){
                float col[3];
                for(int i=0;i<3;i++){
                    col[i]=mF_p[i][j];
                    for(int k=0;k<3;k++)
                        col[i]+=data.beta*mG_p[i][k]*mF_p[k][j];}
                for(int i=0;i<3;i++)
                    mF_p[i][j]=col[i];}
        }

    }

}
