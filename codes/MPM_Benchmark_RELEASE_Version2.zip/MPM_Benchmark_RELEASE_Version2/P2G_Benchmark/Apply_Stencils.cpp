//#####################################################################
// Copyright 2017, Ming Gao, Eftychios Sifakis.
// This file is part of PhysBAM whose distribution is governed by the license contained in the accompanying file PHYSBAM_COPYRIGHT.txt.
//#####################################################################
#include <array>
#include <immintrin.h>

void Apply_Stencils(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float grid_datas[6][8][8][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p)
{
    // si sj sk : smallest i,j,k : [0,6]
    // output 0-2 velocity0 3-5 velocity 6-15 outer_product

    __m256i vCellNodes      =_mm256_set_epi32(73, 72, 65, 64, 9, 8, 1, 0);
    float __attribute__ ((aligned(64))) sum[8];
    using Matrix3x3_Type = float (&)[3][3];

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    int start=m*512+(si+i)*64+(sj+j)*8+(sk+k);
                    __m256i vNodeIndices=_mm256_set1_epi32(start);
                    vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                    __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); // didn't mention
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v_p[m]=0.f;
        for(int v=0;v<8;++v)
        v_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    int start=(m+3)*512+(si+i)*64+(sj+j)*8+(sk+k);
                    __m256i vNodeIndices=_mm256_set1_epi32(start);
                    vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                    __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); // didn't mention
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v0_p[m]=0.f;
        for(int v=0;v<8;++v)
        v0_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
            __m256 vSum0=_mm256_setzero_ps();
            __m256 vSum1=_mm256_setzero_ps();
            __m256 vSum2=_mm256_setzero_ps();
            for(int i=0;i<2;++i)
                for(int j=0;j<2;++j)
                    for(int k=0;k<2;++k)
                    {
                        int start=m*512+(si+i)*64+(sj+j)*8+(sk+k);
                        __m256i vNodeIndices=_mm256_set1_epi32(start);
                        vNodeIndices=_mm256_add_epi32(vNodeIndices,vCellNodes);
                        __m256 vNodeValues=_mm256_i32gather_ps(&(grid_datas[0][0][0][0]),vNodeIndices,4); 

                        __m256 vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][0][0])); 
                        __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum0=_mm256_add_ps(vSumTMP,vSum0);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][1][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum1=_mm256_add_ps(vSumTMP,vSum1);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][2][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum2=_mm256_add_ps(vSumTMP,vSum2);
                    }

            Matrix3x3_Type mG_p=reinterpret_cast<Matrix3x3_Type>(G_p[0]);

            _mm256_store_ps(sum,vSum0);
            for(int v=0;v<8;++v) mG_p[0][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum1);
            for(int v=0;v<8;++v) mG_p[1][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum2);
            for(int v=0;v<8;++v) mG_p[2][m]+=sum[v];

    }
}

void Apply_Stencils_Alt(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float cell_data[6][5][5][5][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p)
{
    // si sj sk : smallest i,j,k : [0,6]
    // output 0-2 velocity0 3-5 velocity 6-15 outer_product

    float __attribute__ ((aligned(64))) sum[8];
    using Matrix3x3_Type = float (&)[3][3];

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    __m256 vNodeValues=_mm256_load_ps(&cell_data[m][i+si][j+sj][k+sk][0]);
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v_p[m]=0.f;
        for(int v=0;v<8;++v)
        v_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
        __m256 vSum=_mm256_setzero_ps();
        for(int i=0;i<2;++i)
            for(int j=0;j<2;++j)
                for(int k=0;k<2;++k)
                {
                    __m256 vNodeValues=_mm256_load_ps(&cell_data[m+3][i+si][j+sj][k+sk][0]);
                    __m256 vWeights=_mm256_load_ps(&(stencils[i*4+j*2+k][0])); // has to be aligned
                    __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeights);
                    vSum=_mm256_add_ps(vSumTMP,vSum);
                }

        _mm256_store_ps(sum,vSum);
        v0_p[m]=0.f;
        for(int v=0;v<8;++v)
        v0_p[m]+=sum[v];
    }

    for(int m=0;m<3;++m)
    {
            __m256 vSum0=_mm256_setzero_ps();
            __m256 vSum1=_mm256_setzero_ps();
            __m256 vSum2=_mm256_setzero_ps();
            for(int i=0;i<2;++i)
                for(int j=0;j<2;++j)
                    for(int k=0;k<2;++k)
                    {
                        __m256 vNodeValues=_mm256_load_ps(&cell_data[m][i+si][j+sj][k+sk][0]);
                        __m256 vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][0][0])); 
                        __m256 vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum0=_mm256_add_ps(vSumTMP,vSum0);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][1][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum1=_mm256_add_ps(vSumTMP,vSum1);

                        vWeightGradients=_mm256_load_ps(&(gstencils[i*4+j*2+k][2][0])); 
                        vSumTMP=_mm256_mul_ps(vNodeValues,vWeightGradients);
                        vSum2=_mm256_add_ps(vSumTMP,vSum2);
                    }

            Matrix3x3_Type mG_p=reinterpret_cast<Matrix3x3_Type>(G_p[0]);

            _mm256_store_ps(sum,vSum0);
            for(int v=0;v<8;++v) mG_p[0][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum1);
            for(int v=0;v<8;++v) mG_p[1][m]+=sum[v];
            _mm256_storeu_ps(sum,vSum2);
            for(int v=0;v<8;++v) mG_p[2][m]+=sum[v];

    }
}


void Apply_Stencils_P2G(const int si,const int sj,const int sk,
        const float walpha,const float wbeta,
        const float mass,const float momentum[3],const float stress[9],
        const float stencils[8][8],const float gstencils[8][3][8],float buffer[7][5][5][5][8])
{

    __m256 vAlpha           = _mm256_broadcast_ss(&walpha);
    __m256 vMass = _mm256_broadcast_ss(&mass);
    __m256 vMomentum0 = _mm256_broadcast_ss(&momentum[0]);
    __m256 vMomentum1 = _mm256_broadcast_ss(&momentum[1]);
    __m256 vMomentum2 = _mm256_broadcast_ss(&momentum[2]);
    for(int i=0;i<2;++i)
    for(int j=0;j<2;++j)
    for(int k=0;k<2;++k)
    {
        __m256 vWeights=_mm256_load_ps(&(stencils[4*i+2*j+k][0])); 
        vWeights=_mm256_mul_ps(vWeights,vAlpha);

        __m256 vStencil=_mm256_mul_ps(vWeights,vMass);

        __m256 vTmp = _mm256_load_ps(&(buffer[0][si+i][sj+j][sk+k][0]));
        vStencil = _mm256_add_ps(vStencil,vTmp);
        _mm256_storeu_ps(buffer[0][si+i][sj+j][sk+k],vStencil);

        vStencil=_mm256_mul_ps(vWeights,vMomentum0);
        vTmp = _mm256_load_ps(&(buffer[1][si+i][sj+j][sk+k][0]));
        vStencil = _mm256_add_ps(vStencil,vTmp);
        _mm256_storeu_ps(buffer[1][si+i][sj+j][sk+k],vStencil);

        vStencil=_mm256_mul_ps(vWeights,vMomentum1);
        vTmp = _mm256_load_ps(&(buffer[2][si+i][sj+j][sk+k][0]));
        vStencil = _mm256_add_ps(vStencil,vTmp);
        _mm256_storeu_ps(buffer[2][si+i][sj+j][sk+k],vStencil);

        vStencil=_mm256_mul_ps(vWeights,vMomentum2);
        vTmp = _mm256_load_ps(&(buffer[3][si+i][sj+j][sk+k][0]));
        vStencil = _mm256_add_ps(vStencil,vTmp);
        _mm256_storeu_ps(buffer[3][si+i][sj+j][sk+k],vStencil);

    }


    __m256 vBeta = _mm256_broadcast_ss(&wbeta);
    __m256 vStress1 = _mm256_broadcast_ss(&stress[0]);
    __m256 vStress2 = _mm256_broadcast_ss(&stress[3]);
    __m256 vStress3 = _mm256_broadcast_ss(&stress[6]);
    __m256 vStress4 = _mm256_broadcast_ss(&stress[1]);
    __m256 vStress5 = _mm256_broadcast_ss(&stress[4]);
    __m256 vStress6 = _mm256_broadcast_ss(&stress[7]);
    __m256 vStress7 = _mm256_broadcast_ss(&stress[2]);
    __m256 vStress8 = _mm256_broadcast_ss(&stress[5]);
    __m256 vStress9 = _mm256_broadcast_ss(&stress[8]);
    for(int i=0;i<2;++i)
    for(int j=0;j<2;++j)
    for(int k=0;k<2;++k)
    {

       __m256 vWG0=_mm256_load_ps(&(gstencils[4*i+2*j+k][0][0])); 
       vWG0=_mm256_mul_ps(vWG0,vBeta);
       __m256 vWG1=_mm256_load_ps(&(gstencils[4*i+2*j+k][1][0])); 
       vWG1=_mm256_mul_ps(vWG1,vBeta);
       __m256 vWG2=_mm256_load_ps(&(gstencils[4*i+2*j+k][2][0])); 
       vWG2=_mm256_mul_ps(vWG2,vBeta);
           
       __m256 vTmp1 = _mm256_mul_ps(vStress1,vWG0);
       __m256 vTmp2 = _mm256_mul_ps(vStress2,vWG1);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       vTmp2 = _mm256_mul_ps(vStress3,vWG2);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       vTmp2 = _mm256_load_ps(&(buffer[4][si+i][sj+j][sk+k][0]));
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       _mm256_storeu_ps(buffer[4][si+i][sj+j][sk+k],vTmp1);
           
       vTmp1 = _mm256_mul_ps(vStress4,vWG0);
       vTmp2 = _mm256_mul_ps(vStress5,vWG1);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       vTmp2 = _mm256_mul_ps(vStress6,vWG2);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       vTmp2 = _mm256_load_ps(&(buffer[5][si+i][sj+j][sk+k][0]));
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       _mm256_storeu_ps(buffer[5][si+i][sj+j][sk+k],vTmp1);
           
       vTmp1 = _mm256_mul_ps(vStress7,vWG0);
       vTmp2 = _mm256_mul_ps(vStress8,vWG1);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       vTmp2 = _mm256_mul_ps(vStress9,vWG2);
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);

       vTmp2 = _mm256_load_ps(&(buffer[6][si+i][sj+j][sk+k][0]));
       vTmp1 = _mm256_add_ps(vTmp1,vTmp2);
       _mm256_storeu_ps(buffer[6][si+i][sj+j][sk+k],vTmp1);
    }
}
