// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#include <immintrin.h>
#include <string.h>

#include "MPM_Data.h"
#include "Build_Stencils.h"
#include "Apply_Stencils.h"

#include <PhysBAM_Tools/Log/LOG.h>

using namespace PhysBAM;
using namespace SPGrid;

#include "MPM_Particle2Grid.h"

//#####################################################################
// Function P2G_Transfer
//#####################################################################
template<>
void P2G_Transfer(MPM_Data<float,3>& data)
{
    constexpr int d = 3;
    using T               = float;
//     using Vector_Type     = std::array<T,d>;
//     using Index_Type      = std_array<int,d>;
    using Data_Array_Mask = MPM_Data<T,d>::Allocator_Type::Array<T>::mask;

    LOG::SCOPE scope("P2G_Transfer");

    const int nblocks=data.G2P_blocks.size();

    using Block_Buffers_Type = T (*)[7][8][8][8];
    using Reshaped_Buffer_Type = T (&)[7][2][4][2][4][2][4];
    using Reshaped_Channel_Type = T (&)[4][4][4];
    using Matrix3x3_Type = T (&)[3][3];

    Block_Buffers_Type block_buffers=reinterpret_cast<Block_Buffers_Type>(data.block_buffers);
    T __attribute__ ((aligned(64))) cell_buffer[7][5][5][5][8];
    T __attribute__ ((aligned(64))) stencils[8][8];
    T __attribute__ ((aligned(64))) gstencils[8][3][8];

#pragma omp parallel for private(cell_buffer,stencils,gstencils) shared(block_buffers)
    for(int b=0;b<nblocks;b++){

        auto buffer=block_buffers[b];

        unsigned long neighbor_offsets[2][2][2];
        neighbor_offsets[0][0][0]=data.G2P_blocks[b];
        neighbor_offsets[0][0][1]=Data_Array_Mask::Packed_Offset<0,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][0]=Data_Array_Mask::Packed_Offset<0,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][1]=Data_Array_Mask::Packed_Offset<0,4,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][0]=Data_Array_Mask::Packed_Offset<4,0,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][1]=Data_Array_Mask::Packed_Offset<4,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][0]=Data_Array_Mask::Packed_Offset<4,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][1]=Data_Array_Mask::Packed_Offset<4,4,4>(data.G2P_blocks[b]);

        Reshaped_Buffer_Type buffer_reshaped=reinterpret_cast<Reshaped_Buffer_Type>(buffer[0][0][0][0]);

#if 1
        memset(&buffer[0][0][0][0],0,7*8*8*8*4);
        memset(&cell_buffer[0][0][0][0][0],0,7*5*5*5*8*4);

        T momentum[3];
        T stress[9];

        for(int pp=data.G2P_offsets[b];pp<data.G2P_offsets[b+1];pp++){

            int p=data.sorted_particle_indices[pp];
            const auto weights=data.trilinear_coordinates_p[p];
            const auto local_offset=data.local_offset_p[p];

            Build_Stencils(weights[0],weights[1],weights[2],data.radius,stencils,gstencils);
            momentum[0]=data.v_p[p][0];
            momentum[1]=data.v_p[p][1];
            momentum[2]=data.v_p[p][2];
            for(int i=0;i<9;++i)
                stress[i]=data.sigma_p[p][i];
            Apply_Stencils_P2G(local_offset[0],local_offset[1],local_offset[2],
                               data.alpha,data.beta,
                               data.m_p[p],momentum,stress,
                               stencils,gstencils,cell_buffer);
        }
        for(int v=0;v<7;v++)
            for(int ci=0;ci<5;ci++)
            for(int cj=0;cj<5;cj++)
            for(int ck=0;ck<5;ck++){

                int q=0;
                for(int vi=0;vi<2;vi++)
                for(int vj=0;vj<2;vj++)
                for(int vk=0;vk<2;vk++)
                    buffer[v][ci+vi][cj+vj][ck+vk]+=cell_buffer[v][ci][cj][ck][q++];

            }
#elif 0
        memset(&buffer[0][0][0][0],0,7*8*8*8*4);

        for(int pp=data.G2P_offsets[b];pp<data.G2P_offsets[b+1];pp++){

            int p=data.sorted_particle_indices[pp];
            const auto weights=data.trilinear_coordinates_p[p];
            const auto local_offset=data.local_offset_p[p];

            Build_Stencils(weights[0],weights[1],weights[2],data.radius,stencils,gstencils);

            {
                T ws[3][3][3]={0};
                T wgs[3][3][3][3]={0};
                for(int ci=0;ci<2;ci++)
                for(int cj=0;cj<2;cj++)
                for(int ck=0;ck<2;ck++){

                    int q=0;
                    for(int vi=0;vi<2;vi++)
                    for(int vj=0;vj<2;vj++)
                    for(int vk=0;vk<2;vk++)
                    {
                        ws[ci+vi][cj+vj][ck+vk]+=stencils[4*ci+2*cj+ck][4*vi+2*vj+vk];
                        wgs[ci+vi][cj+vj][ck+vk][0]+=gstencils[4*ci+2*cj+ck][0][4*vi+2*vj+vk];
                        wgs[ci+vi][cj+vj][ck+vk][1]+=gstencils[4*ci+2*cj+ck][1][4*vi+2*vj+vk];
                        wgs[ci+vi][cj+vj][ck+vk][2]+=gstencils[4*ci+2*cj+ck][2][4*vi+2*vj+vk];
                    }
                }

                T weight;
                std::array<T,d> weightgradients=std::array<T,d>();

                for(int i=0;i<3;++i)
                for(int j=0;j<3;++j)
                for(int k=0;k<3;++k)
                {
                    weight=data.alpha*ws[i][j][k];
                    for(int v=0;v<d;++v)
                        weightgradients[v]=data.beta*wgs[i][j][k][v];

                    buffer[0][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=data.m_p[p]*weight;
                    buffer[1][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=data.v_p[p][0]*weight;
                    buffer[2][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=data.v_p[p][1]*weight;
                    buffer[3][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=data.v_p[p][2]*weight;
                    
                    Matrix3x3_Type mSigma_p=reinterpret_cast<Matrix3x3_Type>(data.sigma_p[p][0]);
                    std::array<T,d> force=std::array<T,d>();
                    for(int v=0;v<d;++v)
                        for(int w=0;w<d;++w)
                            force[v]+=mSigma_p[v][w]*weightgradients[w];
                    buffer[4][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=force[0];
                    buffer[5][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=force[1];
                    buffer[6][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k]+=force[2];

                }
            }
        }
#elif 0
        // Zero out buffers before we do anything else
        //std::cout << "old method " << std::endl;

        memset(&buffer[0][0][0][0],0,7*8*8*8*4);
        memset(&cell_buffer[0][0][0][0][0],0,7*5*5*5*8*4);

        // Process particles of block

        for(int pp=data.G2P_offsets[b];pp<data.G2P_offsets[b+1];pp++){

            int p=data.sorted_particle_indices[pp];
            const auto weights=data.trilinear_coordinates_p[p];
            const auto local_offset=data.local_offset_p[p];

            Build_Stencils(weights[0],weights[1],weights[2],data.radius,stencils,gstencils);

            //for(int v=0;v<7;++v)
            {
                T weight;
                std::array<T,d> weightgradients;
                int cq=-1;
                for(int i=0;i<2;++i)
                    for(int j=0;j<2;++j)
                        for(int k=0;k<2;++k)
                        {
                            ++cq;
                            for(int q=0;q<8;++q){
                                weight=data.alpha*stencils[cq][q];
                                for(int v=0;v<d;++v)
                                    weightgradients[v]=data.beta*gstencils[cq][v][q];

                                cell_buffer[0][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=data.m_p[p]*weight;
                                cell_buffer[1][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=data.v_p[p][0]*weight;
                                cell_buffer[2][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=data.v_p[p][1]*weight;
                                cell_buffer[3][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=data.v_p[p][2]*weight;

                                Matrix3x3_Type mSigma_p=reinterpret_cast<Matrix3x3_Type>(data.sigma_p[p][0]);
                                std::array<T,d> force;
                                for(int v=0;v<d;++v)
                                    for(int w=0;w<d;++w)
                                        force[v]+=mSigma_p[v][w]*weightgradients[w];
                                cell_buffer[4][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=force[0];
                                cell_buffer[5][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=force[1];
                                cell_buffer[6][local_offset[0]+i][local_offset[1]+j][local_offset[2]+k][q]+=force[2];
                            }
                        }
            }
        }

        // Reshape from cell to usual buffer

        for(int v=0;v<7;v++)
            for(int ci=0;ci<5;ci++)
            for(int cj=0;cj<5;cj++)
            for(int ck=0;ck<5;ck++){

                int q=0;
                for(int vi=0;vi<2;vi++)
                for(int vj=0;vj<2;vj++)
                for(int vk=0;vk<2;vk++)
                    buffer[v][ci+vi][cj+vj][ck+vk]+=cell_buffer[v][ci][cj][ck][q++];

            }
#endif
    }



    for(int b=0;b<nblocks;b++){

        auto buffer=block_buffers[b];

        unsigned long neighbor_offsets[2][2][2];
        neighbor_offsets[0][0][0]=data.G2P_blocks[b];
        neighbor_offsets[0][0][1]=Data_Array_Mask::Packed_Offset<0,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][0]=Data_Array_Mask::Packed_Offset<0,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[0][1][1]=Data_Array_Mask::Packed_Offset<0,4,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][0]=Data_Array_Mask::Packed_Offset<4,0,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][0][1]=Data_Array_Mask::Packed_Offset<4,0,4>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][0]=Data_Array_Mask::Packed_Offset<4,4,0>(data.G2P_blocks[b]);
        neighbor_offsets[1][1][1]=Data_Array_Mask::Packed_Offset<4,4,4>(data.G2P_blocks[b]);

        Reshaped_Buffer_Type buffer_reshaped=reinterpret_cast<Reshaped_Buffer_Type>(buffer[0][0][0][0]);

        // Accumulate back to grid

        for(int v=0;v<7;v++){

            auto vg_component_array=data.allocator_ptr->Get_Array(data.output_ptrs[v]);

            for(int bi=0;bi<2;bi++)
            for(int bj=0;bj<2;bj++)
            for(int bk=0;bk<2;bk++){

                Reshaped_Channel_Type channel_reshaped=
                    reinterpret_cast<Reshaped_Channel_Type>(vg_component_array(neighbor_offsets[bi][bj][bk]));

                for(int i=0;i<4;i++)
                for(int j=0;j<4;j++)
                for(int k=0;k<4;k++)
                    channel_reshaped[i][j][k]+=buffer_reshaped[v][bi][i][bj][j][bk][k];

            }
        }
    }

}
