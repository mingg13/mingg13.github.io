//#####################################################################
// Copyright 2017, Ming Gao, Eftychios Sifakis.
// This file is part of PhysBAM whose distribution is governed by the license contained in the accompanying file PHYSBAM_COPYRIGHT.txt.
//#####################################################################

void Apply_Stencils(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float grid_datas[6][8][8][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p);

void Apply_Stencils_Alt(const int si,const int sj,const int sk,
    const float stencils[8][8],const float gstencils[8][3][8],const float cell_data[6][5][5][5][8],
    std::array<float,3>& v_p,std::array<float,3>& v0_p,std::array<float,9>& G_p);

void Apply_Stencils_P2G(const int si,const int sj,const int sk,
        const float walpha,const float wbeta,
        const float mass,const float momentum[3],const float stress[9],
        const float stencils[8][8],const float gstencils[8][3][8],float buffer[7][5][5][5][8]);

