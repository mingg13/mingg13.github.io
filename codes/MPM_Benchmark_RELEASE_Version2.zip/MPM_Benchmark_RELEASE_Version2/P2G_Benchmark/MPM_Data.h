// Copyright (C) 2017, Anonymous Authors of submission papers_0282

#ifndef __MPM_Data_h__
#define __MPM_Data_h__

#include <SPGrid/Core/SPGrid_Allocator.h>

#include <vector>
#include <array>

#include "MPM_Grid_Data.h"

using namespace SPGrid;

template<class T,int d>
struct MPM_Data
{
    using Struct_Type    = MPM_Grid_Data<T>;
    using Allocator_Type = SPGrid_Allocator<Struct_Type,d>;

    // Particle data

    std::vector<T> m_p;
    std::vector<T> V0_p;
    std::vector<std::array<T,d> > x_p;
    std::vector<std::array<T,d> > v_p;
    std::vector<std::array<T,d*d> > sigma_p;

    // Grid data

    Allocator_Type *allocator_ptr;
    std::array<T Struct_Type::*,7> output_ptrs;

    // Geometry data

    T dx;
    T dt;
    T radius;
    T alpha;
    T beta;

    // Embedding data

    std::vector<unsigned long> base_offset_p;
    std::vector<std::array<int,d> > local_offset_p;
    std::vector<std::array<T,d> > trilinear_coordinates_p;

    // Parallelization auxiliary data

    std::vector<int> sorted_particle_indices;
    std::vector<unsigned long> G2P_blocks;
    std::vector<int> G2P_offsets;
    void *block_buffers;

    MPM_Data()
        :output_ptrs{{&Struct_Type::ch0,&Struct_Type::ch1,&Struct_Type::ch2,
        &Struct_Type::ch3,&Struct_Type::ch4,&Struct_Type::ch5,&Struct_Type::ch6}}
    {
        static_assert(d==3,"Only 3D supported");
    }
    
    void Initialize_SPGrid(const int xsize,const int ysize,const int zsize)
    {
        allocator_ptr=new Allocator_Type(xsize,ysize,zsize);
    }
};

#endif
